# adaptive-fixed2
